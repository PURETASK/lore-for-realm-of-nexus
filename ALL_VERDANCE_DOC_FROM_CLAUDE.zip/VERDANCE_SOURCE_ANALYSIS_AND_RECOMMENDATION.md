# Verdance — Source Document Analysis & Forward Recommendation

**Analyzed:** 24 documents across the uploaded zip  
**Document types:** ChatGPT conversation logs (majority), original prose drafts, codex entries, story chapters  
**Analysis date:** Current session

---

## BOTTOM LINE UP FRONT

**Do not restart.** The 7 topics we've built are structurally superior to anything in the source documents. But we need to pause, reconcile several specific lore conflicts, and add missing content before continuing. This document tells you exactly what needs to change and why.

---

## WHAT I FOUND IN THE ZIP

### The Documents Are Mostly ChatGPT Conversation Logs
Most of the 24 files are transcripts of ChatGPT worldbuilding sessions — not polished canon. They represent different iterations of Verdance across months of development, with inconsistencies between them. There is no single "master source" — the files disagree with each other in places. This means our lore bible is actually the first true attempt to synthesize everything into one coherent framework.

### There IS an Actual Novel Being Written
**SCENE2.pdf** and **123.pdf** contain beautifully written prose chapters with specific POV characters:
- **Serenya** — a young girl with prophetic visions, the protagonist
- **Aldric** — a young man and warrior in her village (NOT yet the Everwood)
- **Sylor** — already Aldric's companion and friend
- **Elder Maelith**, **Waykeeper Rook**, **Healer Fen** — village characters

The novel appears to be set **right before the transformation** — during a severe, extended Crimson Phase famine. Serenya has a prophetic dream about Aldric merging with the Everwood ("He will bleed, and you will see"). The story is building toward the transformation event our lore bible describes.

**This is critical:** our lore bible is support material for this novel. Everything we write should serve the story being told in SCENE2.

---

## THE FIVE THINGS THAT NEED TO BE RECONCILED

### 1. THE VERDANT NEXUS STONE — Major Gap in Our Docs

The source documents consistently describe the transformation involving a physical artifact called the **Verdant Nexus Stone** — an ancient crystal at the grove's center into which Aldric performed a blood sacrifice that triggered the transformation. Our Topics 5 and 7 describe a three-day consciousness merger with no mention of this artifact.

**Verdict:** This is a real gap, not a contradiction. The Nexus Stone can slot perfectly into our existing narrative — it's the physical interface point at the grove's center, the object Aldric placed his hands on at the start of Day One. The "blood sacrifice" version seen in some source docs is likely the mythologized account (what the crowd witnessed from outside the grove) while our internal account of the three-day merger is what actually happened.

**Action required:** Retrofit the Nexus Stone into Topics 5 and 7 with a brief revision note, and build it properly into future topics.

### 2. SOULBORN + VERDANT SIGIL MECHANICS — Entirely Missing

The **Soul Magic Codex** document contains detailed mechanics that aren't in any of our seven topics:
- **Soulborn** — rare individuals who emerge specifically during the Silver Phase, reborn into new form. They cannot reproduce. Society treats their arrival as a sacred event.
- **Verdant Sigils** — bioluminescent body markings that appear on Soulborn at awakening, reflecting what type of soul magic they're destined for. They glow brighter during Silver Phase, dim during Crimson.
- **Soul Magic Specializations** — Soulforging, Burn Magic, Ancestor Communion, Soulbinding, Soul Shields (at minimum)

**Verdict:** This is substantial missing content that needs its own topics. Soulborn are clearly significant to the novel since they're the human-scale manifestation of the Great Unbinding's soul-release.

**Action required:** Add Soulborn and Verdant Sigils as dedicated topics. (Approximately Topics 12-13 in our sequence.)

### 3. THE ARCHITECTS + THE KEEPER — Cosmological Origin Missing

The source contains a creation myth that our docs completely lack:

**Six Architects** shaped reality using the First Nexus Stone:
- **Solthar** (Fire) → Radiance domain
- **Auranth** (Wind) → Tempest domain
- **Lunara** (Nature/Cycles) → Verdance domain
- **Seran Valeheart** (Light) → Sanctuary domain
- **Virexus** (Death) → Abyss domain
- **Vael'thar / The Keeper** (Forbidden Knowledge) → the villain

Vael'thar betrayed the others, stole the First Nexus Stone's power, and the remaining five Architects sacrificed themselves to shatter it — locking Vael'thar in a prison. The shards became each domain's Nexus Stone.

**The Keeper's whispers** are an overarching plot threat — he corrupts domain leaders from imprisonment, which is the engine behind the "PERFECT STORY" arc.

**Verdict:** This is the cosmological foundation that gives the Realm of Nexus its stakes. Verdance's Verdant Nexus Stone is a shard of the First Nexus Stone containing Lunara's essence. This is powerful lore. It also gives the Thornborn Ascendants a deeper motivation — they may be unknowingly serving the Keeper's interests.

**Action required:** Add the Architects and the Keeper as early topics (suggest inserting as Topic 4.5 — between our Realm of Nexus topic and Aldric). Also add this context to the Realm of Nexus document we already built.

### 4. NAMING CONFLICTS — Minor but Real

| Element | Our Documents | Source Documents | Recommended Resolution |
|---|---|---|---|
| The internal cult threat | Thornweave Cult / Nytheris | Thornborn Ascendants / Lorian | **Thornborn Ascendants** is the historical group; **Thornweave Cult** is the current-era incarnation. Lorian was the original leader; Nytheris leads the modern version. |
| Soul War Verdant champion | Vaeril Greenshield (General) | Also Eldros Greenward in some docs | Source docs are inconsistent here. **Vaeril Greenshield** appears more frequently and in our already-built docs. Keep Vaeril. Eldros may be a different battle. |
| Soul War era ruler | Not mentioned | King Thalorien | Add King Thalorien as the political authority during the Soul War era — he was the ruler while Vaeril Greenshield commanded militarily. |
| Dreamwalker Caellind | In our Topic 5 quotes | Not in source | Our character — keep. |

### 5. THE TRANSFORMATION NARRATIVE — Partially Different

Source documents describe Aldric's transformation as a dramatic public event: blood drawn, Nexus Stone flares with green-white light, Aldric's body dissolves upward into the light, and a massive tree erupts from the ground in seconds. This is spectacular and cinematic.

Our Topic 7 describes a three-day gradual process witnessed by only Sylor.

**Verdict:** These can be reconciled as two accounts of the same event from different perspectives. The crowd outside the grove saw a dramatic, compressed version — the Nexus Stone flaring, Aldric's form dissolving, the tree erupting. The internal reality (Sylor's account, our Topic 7) shows the three days of consciousness work that preceded that dramatic physical moment, with the visible "eruption" being the Day Three completion event. The mythologized, crowd-witnessed account becomes the basis of the public legend. Sylor's account becomes the private truth that the Coven preserves.

**Action required:** Revise Topic 7 slightly to include the public-facing dramatic moment and the Nexus Stone. The three-day framework stays intact — it's what preceded and produced that moment.

---

## WHAT THE NOVEL NEEDS FROM THE LORE BIBLE

Reading SCENE2 carefully, the story requires these things to be well-defined:

**Village life during a prolonged Crimson Phase** — famine conditions, rationing, community psychology, what the Bloomguard does during this period. Our docs cover this at the strategic level; the novel needs the ground-level texture.

**Serenya as a prophetic child** — she has visions that connect to the Everwood. This likely makes her a proto-Soulborn or spiritually attuned individual. Her story ends (or pivots) at the transformation, suggesting she witnesses the event Aldric is building toward.

**Aldric as a young man, pre-transformation** — the novel shows him at roughly the age he'll be when he transforms. He's a warrior and community figure, not yet the Bloomwarden in the formal sense, but clearly developing toward it. His relationship with Sylor is already established.

**The transformation as a witnessed event** — from Serenya's POV, she'll presumably see something of the transformation (her prophetic dream says "He will bleed, and you will see"). This means Topic 7's narrative needs to be written with the possibility of Serenya witnessing the crowd-side dramatic moment even if she can't see the three days in the grove.

---

## THE FORWARD PLAN — THREE OPTIONS

### Option A: Pause, Reconcile, Then Continue (RECOMMENDED)
**What:** Before building Topic 8, produce a short "Canon Reconciliation" document that formally incorporates the Nexus Stone, names the Thornborn Ascendants as the historical predecessor to the Thornweave Cult, introduces the Architects and Keeper cosmology, and establishes the Soulborn as a topic to address. Then continue the topic series from Topic 8 onward with these elements baked in.

**Why this is best:** Clean. Our framework stays intact. We don't rebuild what's already strong. We fill the gaps without disrupting the sequence.

**Time cost:** One reconciliation document + minor revision notes for Topics 5 and 7. Then forward.

### Option B: Insert Missing Topics, Adjust Numbering
**What:** Insert 3-4 new topics before picking up Topic 8: Architects + Keeper (new Topic 4.5), Verdant Nexus Stone (new dedicated topic), Soulborn + Verdant Sigils. Renumber accordingly.

**Why this might be better:** Puts the cosmological foundation in place before we go deeper into later eras. If the novel eventually needs this content, having it as standalone documents is useful.

**Time cost:** Moderate. 3-4 new documents before Topic 8.

### Option C: Restart With Full Source Integration
**What:** Start over from Topic 1, this time explicitly incorporating every source element from the beginning.

**Why this is wrong:** Our existing 7 topics are better organized, more internally consistent, and more sophisticated than anything in the source documents. Restarting to "include more" would mean degrading the quality to incorporate material that was already inconsistent with itself. The work we've done doesn't need to be undone — it needs to be extended and reconciled.

---

## RECOMMENDATION

**Go with Option A, enhanced by Option B's insertion of key missing topics.**

Specifically:
1. Build a **Canon Reconciliation + Gap Fill** document (not a topic, just a working reference)
2. Insert these as new documents before Topic 8:
   - **Topic 4.5:** The Architects, the Keeper, and the Origin of the Nexus Stones
   - **Topic 8 (renumbered):** Soulborn — The Silver Phase's Human Miracle + Verdant Sigils
3. Revise Topics 5 and 7 with a brief addendum note about the Verdant Nexus Stone (no need to rebuild them from scratch — a footnote is sufficient)
4. Continue forward

**The novel is the anchor.** Everything should be written with Serenya's story in mind. She is in a village during a Crimson Phase famine. She knows Aldric. She will witness something she prophesied. The lore bible supports the world she lives in.

---

## CHARACTERS FOUND IN SOURCE NOT YET IN OUR DOCUMENTS

| Character | Role | Source Doc | Notes |
|---|---|---|---|
| Serenya | Novel protagonist, prophetic child | SCENE2, 123 | Primary POV of the novel being written |
| Elder Maelith | Village elder | SCENE2 | Key community authority figure |
| Waykeeper Rook | Lorekeeper | SCENE2 | Holds oral history and prophecy |
| Healer Fen | Village healer, pragmatist | SCENE2 | Counterbalance to mysticism |
| King Thalorien | Verdant ruler during Soul War | Soul War story | Political authority, greeted Abyssian ambassador Siralor |
| Siralor of the Shadow Court | Abyssian ambassador | Soul War story | Preceded the invasion |
| Vorastril the Dusk Herald | Abyssian champion, Soul War | Soul War story | Antagonist of the Soul War conflict |
| Lorian | Thornborn Ascendants founder | Shattered Communion | Historical predecessor of Nytheris |
| Commander Elyndra | Bloomguard commander vs. Thornborn | Battle at Temple | Active military figure |
| Oris | Bloomguard scout, Elyndra's ally | Battle at Temple | Supporting character |
| Alenya | Emerald Coven, vs. Thornborn | Battle at Temple | Her former mentor joined the Thornborn |
| Vael'thar / The Keeper | Imprisoned divine villain | Realm Creation | Overarching threat for full story arc |

---

*Analysis complete. Awaiting your direction on which option to proceed with.*
